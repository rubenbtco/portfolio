-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mar. 28 avr. 2026 à 00:36
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `ruben_slam_td1`
--

-- --------------------------------------------------------

--
-- Structure de la table `candidat`
--

CREATE TABLE `candidat` (
  `id` int(11) NOT NULL,
  `nom` varchar(50) DEFAULT NULL,
  `prenom` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `candidat`
--

INSERT INTO `candidat` (`id`, `nom`, `prenom`) VALUES
(1, 'Touille', 'Rata'),
(2, 'L\'éponge', 'Bob'),
(3, 'Man', 'Spider');

-- --------------------------------------------------------

--
-- Structure de la table `jury`
--

CREATE TABLE `jury` (
  `id` int(11) NOT NULL,
  `nom` varchar(50) DEFAULT NULL,
  `prenom` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `jury`
--

INSERT INTO `jury` (`id`, `nom`, `prenom`) VALUES
(1, 'Gravouil', 'Benjamin'),
(2, 'Dindar', 'Djamil'),
(3, 'Ducasse', 'Alain'),
(4, 'Bo', 'Harry'),
(5, 'Tout', 'Bouffe');

-- --------------------------------------------------------

--
-- Structure de la table `noter`
--

CREATE TABLE `noter` (
  `IdCandidat` int(11) NOT NULL,
  `idPlat` int(11) NOT NULL,
  `idJury` int(11) NOT NULL,
  `note` decimal(4,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `noter`
--

INSERT INTO `noter` (`IdCandidat`, `idPlat`, `idJury`, `note`) VALUES
(1, 1, 1, 12.00),
(1, 1, 2, 15.00),
(1, 1, 3, 11.00),
(1, 1, 4, 13.00),
(1, 1, 5, 18.00),
(1, 2, 1, 11.00),
(1, 2, 2, 12.00),
(1, 2, 3, 4.00),
(1, 2, 4, 11.00),
(1, 2, 5, 17.00),
(1, 3, 1, 15.00),
(1, 3, 2, 15.00),
(1, 3, 3, 15.00),
(1, 3, 4, 13.00),
(1, 3, 5, 14.00),
(2, 1, 1, 18.00),
(2, 1, 2, 14.00),
(2, 1, 3, 12.00),
(2, 1, 4, 11.00),
(2, 1, 5, 18.00),
(2, 2, 1, 11.00),
(2, 2, 2, 13.00),
(2, 2, 3, 4.00),
(2, 2, 4, 11.00),
(2, 2, 5, 16.00),
(2, 3, 1, 12.00),
(2, 3, 2, 12.00),
(2, 3, 3, 8.00),
(2, 3, 4, 13.00),
(2, 3, 5, 20.00),
(3, 1, 1, 18.00),
(3, 1, 2, 12.00),
(3, 1, 3, 5.00),
(3, 1, 4, 7.00),
(3, 1, 5, 18.00),
(3, 2, 1, 9.00),
(3, 2, 2, 14.00),
(3, 2, 3, 4.00),
(3, 2, 4, 12.00),
(3, 2, 5, 16.00),
(3, 3, 1, 11.00),
(3, 3, 2, 12.00),
(3, 3, 3, 12.00),
(3, 3, 4, 14.00),
(3, 3, 5, 20.00);

-- --------------------------------------------------------

--
-- Structure de la table `plat`
--

CREATE TABLE `plat` (
  `id` int(11) NOT NULL,
  `description` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `plat`
--

INSERT INTO `plat` (`id`, `description`) VALUES
(1, 'Entrée'),
(2, 'Plat principal'),
(3, 'Dessert');

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `vue_moyenne_candidat`
-- (Voir ci-dessous la vue réelle)
--
CREATE TABLE `vue_moyenne_candidat` (
`nom` varchar(50)
,`prenom` varchar(50)
,`note_moyenne` decimal(8,6)
);

-- --------------------------------------------------------

--
-- Structure de la vue `vue_moyenne_candidat`
--
DROP TABLE IF EXISTS `vue_moyenne_candidat`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vue_moyenne_candidat`  AS SELECT `c`.`nom` AS `nom`, `c`.`prenom` AS `prenom`, avg(`n`.`note`) AS `note_moyenne` FROM (`candidat` `c` join `noter` `n` on(`c`.`id` = `n`.`IdCandidat`)) GROUP BY `c`.`id`, `c`.`nom`, `c`.`prenom` ;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `candidat`
--
ALTER TABLE `candidat`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `jury`
--
ALTER TABLE `jury`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `noter`
--
ALTER TABLE `noter`
  ADD PRIMARY KEY (`IdCandidat`,`idPlat`,`idJury`),
  ADD KEY `idPlat` (`idPlat`),
  ADD KEY `idJury` (`idJury`);

--
-- Index pour la table `plat`
--
ALTER TABLE `plat`
  ADD PRIMARY KEY (`id`);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `noter`
--
ALTER TABLE `noter`
  ADD CONSTRAINT `noter_ibfk_1` FOREIGN KEY (`IdCandidat`) REFERENCES `candidat` (`id`),
  ADD CONSTRAINT `noter_ibfk_2` FOREIGN KEY (`idPlat`) REFERENCES `plat` (`id`),
  ADD CONSTRAINT `noter_ibfk_3` FOREIGN KEY (`idJury`) REFERENCES `jury` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
