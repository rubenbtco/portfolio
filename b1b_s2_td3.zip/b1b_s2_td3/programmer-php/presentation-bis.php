<?php
$prenom = "Ruben";
$classe = "BTS SIO SLAM 1ère année";
$langages = array(
    "C#" => 3,
    "PHP" => 1,
    "HTML" => 3,
    "CSS" => 3,
    "JavaScript" => 2
);
$nbLangages = count($langages);

if ($nbLangages < 3) {
    $experience = "débutant";
} elseif ($nbLangages <= 4) {
    $experience = "débrouillé";
} else {
    $experience = "aguerri";
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>La page de <?php echo $prenom; ?></title>
</head>
<body>
    <h1>Ma présentation</h1>
    <p>Bonjour, je m'appelle <?php echo $prenom; ?> et je suis en <?php echo $classe; ?>.</p>
    <p>Je suis un programmeur <?php echo $experience; ?>. Je connais <?php echo $nbLangages; ?> langages de programmation :</p>
    <ul>
        <?php
        foreach ($langages as $langage => $niveau) {
            echo "<li>$langage : niveau $niveau</li>";
        }
        ?>
    </ul>
</body>
</html>