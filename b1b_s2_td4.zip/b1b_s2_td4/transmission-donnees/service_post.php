<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Service sélectionné</title>
</head>
<body>
    <?php
    if (isset($_POST['service'])) {
        $code = htmlspecialchars($_POST['service']);
        echo "<p>Le code du service choisi est $code</p>";
    }
    ?>
</body>
</html>