<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Bonjour</title>
</head>
<body>
    <form action="" method="post">
        <p>
            <label>Entrez votre prénom : <input type="text" name="prenom" required></label>
        </p>
        <p>
            <label>Cochez pour un bonjour plus familier : <input type="checkbox" name="familier"></label>
        </p>
        <p>
            <label><input type="radio" name="politesse" value="mademoiselle"> Mademoiselle</label><br>
            <label><input type="radio" name="politesse" value="madame"> Madame</label><br>
            <label><input type="radio" name="politesse" value="monsieur"> Monsieur</label>
        </p>
        <p>
            <button type="submit">Dire bonjour</button>
        </p>
    </form>
    
    <?php
    if (isset($_POST['prenom'])) {
        $prenom = htmlspecialchars($_POST['prenom']);
        $salutation = isset($_POST['familier']) ? "Salut" : "Bonjour";
        $politesse = isset($_POST['politesse']) ? htmlspecialchars($_POST['politesse']) . " " : "";
        
        echo "<p>$salutation $politesse$prenom !</p>";
    }
    ?>
</body>
</html>