<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Machine à café</title>
</head>
<body>
    <h1>Votre boisson</h1>
    <form action="" method="post">
        <p><label>Nom : <input type="text" name="nom" required></label></p>
        <p><label>Prénom : <input type="text" name="prenom" required></label></p>
        <p>
            <label>Choisissez votre boisson : 
                <select name="boisson">
                    <option value="Café">Café</option>
                    <option value="Thé">Thé</option>
                    <option value="Chocolat">Chocolat</option>
                    <option value="Café crème">Café crème</option>
                </select>
            </label>
        </p>
        <p>
            <label><input type="radio" name="sucre" value="Oui" checked> Sucre</label><br>
            <label><input type="radio" name="sucre" value="Non"> Sans sucre</label>
        </p>
        <p>
            <button type="submit">Valider</button>
            <button type="reset">Annuler</button>
        </p>
    </form>

    <?php
    if (isset($_POST['nom']) && isset($_POST['prenom']) && isset($_POST['boisson']) && isset($_POST['sucre'])) {
        $nom = htmlspecialchars($_POST['nom']);
        $prenom = htmlspecialchars($_POST['prenom']);
        $boisson = htmlspecialchars($_POST['boisson']);
        $sucre = htmlspecialchars($_POST['sucre']);
        
        echo "<p>Bonjour $prenom $nom<br>";
        echo "Votre choix : $boisson<br>";
        echo "Sucre : $sucre</p>";
    }
    ?>
</body>
</html>