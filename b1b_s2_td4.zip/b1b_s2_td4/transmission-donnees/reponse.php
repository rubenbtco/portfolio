<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Réponse</title>
</head>
<body>
    <?php
    if (isset($_POST['prenom'])) {
        $prenom = htmlspecialchars($_POST['prenom']);
        $salutation = isset($_POST['familier']) ? "Salut" : "Bonjour";
        $politesse = isset($_POST['politesse']) ? htmlspecialchars($_POST['politesse']) . " " : "";
        
        echo "<p>$salutation $politesse$prenom !</p>";
    }
    ?>
</body>
</html>