<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Sélection du service</title>
</head>
<body>
    <h1>Choix d'un service</h1>
    <form action="service_post.php" method="post">
        <p>
            <label>Service : 
                <select name="service">
                    <option value="s01">Administration</option>
                    <option value="s02">Commercial</option>
                    <option value="s03">Emballage</option>
                    <option value="s04">Fabrication</option>
                </select>
            </label>
        </p>
        <p>
            <button type="submit">Sélectionner</button>
        </p>
    </form>
</body>
</html>