-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mar. 28 avr. 2026 à 09:04
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `ruben_slam_td2`
--

-- --------------------------------------------------------

--
-- Structure de la table `composition`
--

CREATE TABLE `composition` (
  `ComposantId` varchar(50) NOT NULL,
  `ComposeId` varchar(50) NOT NULL,
  `Quantite` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `composition`
--

INSERT INTO `composition` (`ComposantId`, `ComposeId`, `Quantite`) VALUES
('aile', 'aileron', 1),
('aile', 'longeron', 5),
('aile', 'rivet', 100),
('aile', 'train', 1),
('aileron', 'charnière', 2),
('aileron', 'rivet', 5),
('charnière', 'rivet', 4),
('longeron', 'rivet', 10),
('train', 'charnière', 3),
('train', 'rivet', 8);

-- --------------------------------------------------------

--
-- Structure de la table `piece`
--

CREATE TABLE `piece` (
  `PieceId` varchar(50) NOT NULL,
  `PieceNom` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `piece`
--

INSERT INTO `piece` (`PieceId`, `PieceNom`) VALUES
('aile', 'Aile d\'avion'),
('aileron', 'Aileron d\'aile'),
('charnière', 'Charnière à tout faire'),
('longeron', 'Longeron d\'aile'),
('rivet', 'rivets à la pelle'),
('train', 'Train de machin');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `composition`
--
ALTER TABLE `composition`
  ADD PRIMARY KEY (`ComposantId`,`ComposeId`),
  ADD KEY `ComposeId` (`ComposeId`);

--
-- Index pour la table `piece`
--
ALTER TABLE `piece`
  ADD PRIMARY KEY (`PieceId`);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `composition`
--
ALTER TABLE `composition`
  ADD CONSTRAINT `composition_ibfk_1` FOREIGN KEY (`ComposantId`) REFERENCES `piece` (`PieceId`),
  ADD CONSTRAINT `composition_ibfk_2` FOREIGN KEY (`ComposeId`) REFERENCES `piece` (`PieceId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
