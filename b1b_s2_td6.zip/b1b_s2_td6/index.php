<?php
session_start();
if (isset($_SESSION['login']) && isset($_SESSION['nom']) && isset($_SESSION['prenom'])) {
    $nom = $_SESSION['nom'];
    $prenom = $_SESSION['prenom'];
}
require 'fonctions.php';
?>
<!doctype html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>Accueil du site</title>
</head>
<body>
    <?php if (isset($nom) && isset($prenom)): ?>
        <p>Bienvenue, <?= escape($prenom) ?> <?= escape($nom) ?>.</p>
        <h1>Accueil du site</h1>
    <?php else: ?>
        <p>L'accès à cette page est réservé aux utilisateurs authentifiés</p>
        <p><a href="login.php">Se connecter</a></p>
    <?php endif; ?>
</body>
</html>