<?php
session_start();
$erreur = "";

if (isset($_POST['login']) && isset($_POST['mdp'])) {
    require 'fonctions.php';
    $bdd = getBdd();
    
    $login = $_POST['login'];
    $mdp = $_POST['mdp'];
    
    $requete = "SELECT * FROM utilis WHERE LoginUtil = ?";
    $resultat = $bdd->prepare($requete);
    $resultat->execute(array($login));
    
    if ($resultat->rowCount() == 1) {
        $utilisateur = $resultat->fetch();
        if ($utilisateur['PassUtil'] === $mdp) {
            $_SESSION['login'] = $utilisateur['LoginUtil'];
            $_SESSION['nom'] = $utilisateur['NomUtil'];
            $_SESSION['prenom'] = $utilisateur['PrenomUtil'];
            $authOK = true;
        } else {
            $erreur = "Mot de passe incorrect.";
        }
    } else {
        $erreur = "Login inconnu.";
    }
}
?>
<!doctype html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>Résultat de l'authentification</title>
</head>
<body>
    <h1>Résultat de l'authentification</h1>
    <?php if (isset($authOK)): ?>
        <p>Vous avez été reconnu(e) en tant que <?= escape($_SESSION['login']) ?></p>
        <p><a href="index.php">Poursuivre vers la page d'accueil</a></p>
    <?php else: ?>
        <p>Vous n'avez pas été reconnu(e).</p>
        <p><?= escape($erreur) ?></p>
        <p><a href="login.php">Nouvel essai</a></p>
    <?php endif; ?>
</body>
</html>