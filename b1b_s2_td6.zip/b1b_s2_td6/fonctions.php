<?php
function escape($valeur) {
    return htmlspecialchars($valeur, ENT_QUOTES, 'UTF-8', false);
}

function getBdd() {
    return new PDO("mysql:host=localhost;dbname=monsite;charset=utf8", "root", "", array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
}
?>