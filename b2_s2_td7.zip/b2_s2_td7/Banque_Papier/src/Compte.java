public class Compte {
    protected String numero;
    protected Client titulaire;
    protected double solde;
    protected String devise;

    public Compte(String numero, Client titulaire, double solde, String devise) {
        this.numero = numero;
        this.titulaire = titulaire;
        this.solde = solde;
        this.devise = devise;
    }

    public double getSolde() { return solde; }
    public void setSolde(double solde) { this.solde = solde; }

    public void crediter(double montant) {
        if(montant > 0) { this.solde += montant; }
    }

    public void debiter(double montant) {
        if(montant > 0) { this.solde -= montant; }
    }

    public String Decrire() {
        return "n° : " + this.numero + " - solde : " + this.solde + " " + this.devise;
    }
}