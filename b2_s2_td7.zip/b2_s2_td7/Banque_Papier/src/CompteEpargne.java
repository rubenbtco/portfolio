public class CompteEpargne extends Compte {
    private double taux;

    public CompteEpargne(String numero, Client titulaire, double solde, String devise, double taux) {
        super(numero, titulaire, solde, devise);
        this.taux = taux;
    }

    public double getTaux() { return taux; }
    public void setTaux(double taux) { this.taux = taux; }

    // Question 11 : Redéfinition de la méthode Decrire
    @Override
    public String Decrire() {
        int tauxPourcentage = (int)(this.taux * 100);
        return "Compte Epargne " + super.Decrire() + " - taux = " + tauxPourcentage + "%";
    }

    public void ajouter_interet() {
        if (this.solde > 0) {
            this.solde = this.solde + (this.solde * this.taux);
        }
    }
}