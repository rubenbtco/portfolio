import java.util.ArrayList;
import java.util.List;

public class Client {
    private String nom;
    private String prenom;
    private int genre; // 1 pour homme ; 2 pour femme
    private String dateNaissance;
    private String categorie;
    private String adresse;
    private String telephone;
    private String email;

    private List<Compte> listeComptes;

    public Client(String nom, String prenom, int genre, String dateNaissance,
                  String categorie, String adresse, String telephone, String email) {
        this.nom = nom;
        this.prenom = prenom;
        this.genre = genre;
        this.dateNaissance = dateNaissance;
        this.categorie = categorie;
        this.adresse = adresse;
        this.telephone = telephone;
        this.email = email;

        this.listeComptes = new ArrayList<>();
    }

    public void ajouterCompte(Compte compte) {
        this.listeComptes.add(compte);
    }


    public void info_comptes() {
        String civilite = (this.genre == 1) ? "M." : "Mme";
        System.out.println("Liste des comptes de " + civilite + " " + this.nom + " " + this.prenom);
        for (Compte c : this.listeComptes) {
            System.out.println(c.Decrire());
        }
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }
}