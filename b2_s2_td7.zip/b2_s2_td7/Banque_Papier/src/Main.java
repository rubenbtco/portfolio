import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Client martin = new Client("Martin", "Benjamin", 1, "02/05/1977", "enseignant", "5 boulevard AB 06000 Nice", "01.01.01.01.01", "gravouilG@gmail.com");

        ArrayList<Compte> listeComptes = new ArrayList<>();

        listeComptes.add(new Compte("13245411324", martin, 2548200, "€"));
        listeComptes.add(new CompteEpargne("32544771289", martin, 1000, "€", 0.05));
        listeComptes.add(new Compte("22544771289", martin, -214, "€"));

        System.out.println("Liste des comptes du client :");
        for(Compte c : listeComptes) {
            System.out.println(c.Decrire());
        }
        for(Compte c : listeComptes) {
            if (c instanceof CompteEpargne) {
                CompteEpargne ce = (CompteEpargne) c;
                ce.ajouter_interet();
            }
        }
    }
}