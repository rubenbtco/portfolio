public class Compte {
    protected String numero; // On utilise protected pour l'héritage plus tard
    protected Client titulaire;
    protected double solde;
    protected String devise;

    // Constructeur (Question 2)
    public Compte(String numero, Client titulaire, double solde, String devise) {
        this.numero = numero;
        this.titulaire = titulaire;
        this.solde = solde;
        this.devise = devise;
    }

    // Question 3 : Méthodes débiter et créditer
    public void crediter(double montant) {
        if(montant > 0) { this.solde += montant; }
    }

    public void debiter(double montant) {
        if(montant > 0) { this.solde -= montant; }
    }

    // Question 4 : Méthode Decrire
    public String Decrire() {
        return "n° : " + this.numero + " - solde : " + this.solde + " " + this.devise; // Exemple : n°: 13245411324 - solde: 548200 € [cite: 26]
    }
}