import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MenuPrincipal extends JFrame {

    private JButton btnCreaClient;
    private JButton btnGestClient;
    private JButton btnCreaCompte;
    private JButton btnGestCompte;

    public MenuPrincipal() {
        setTitle("Banque - Menu Principal");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(4, 1, 10, 10));

        btnCreaClient = new JButton("Création Client");
        btnGestClient = new JButton("Gestion Client");
        btnCreaCompte = new JButton("Création Compte");
        btnGestCompte = new JButton("Gestion Compte");

        add(btnCreaClient);
        add(btnGestClient);
        add(btnCreaCompte);
        add(btnGestCompte);

        btnCreaCompte.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                FenetreCreationCompte fenetreCompte = new FenetreCreationCompte();
                fenetreCompte.setVisible(true);
            }
        });
    }

    public static void main(String[] args) {
        MenuPrincipal menu = new MenuPrincipal();
        menu.setVisible(true);
    }
}