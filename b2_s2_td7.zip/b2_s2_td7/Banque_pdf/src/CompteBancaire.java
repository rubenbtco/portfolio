public abstract class CompteBancaire {
    protected String numero;
    protected Client titulaire;
    protected double solde;
    protected String devise;

    public CompteBancaire(String numero, Client titulaire, double solde, String devise) {
        this.numero = numero;
        this.titulaire = titulaire;
        this.solde = solde;
        this.devise = devise;
    }

    public void crediter(double montant) {
        if(montant > 0) {
            this.solde += montant;
        }
    }

    public abstract void debiter(double montant);

    public String Decrire() {
        return "n° : " + this.numero + " - solde : " + this.solde + " " + this.devise;
    }
}