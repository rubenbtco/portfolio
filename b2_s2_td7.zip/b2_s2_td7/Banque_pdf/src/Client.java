import java.util.ArrayList;

public class Client {
    private String nom;
    private String prenom;
    private int genre;
    private String dateNaissance;
    private String categorie;
    private String adresse;
    private String telephone;
    private String email;
    private ArrayList<CompteBancaire> listeComptes;

    public Client(String nom, String prenom, int genre, String dateNaissance, String categorie, String adresse, String telephone, String email) {
        this.nom = nom;
        this.prenom = prenom;
        this.genre = genre;
        this.dateNaissance = dateNaissance;
        this.categorie = categorie;
        this.adresse = adresse;
        this.telephone = telephone;
        this.email = email;
        this.listeComptes = new ArrayList<>();
    }

    public void ajouterCompte(CompteBancaire c) {
        this.listeComptes.add(c);
    }

    public void info_comptes() {
        String civilite = (this.genre == 1) ? "M." : "Mme";
        System.out.println("Liste des comptes de " + civilite + " " + this.nom + " " + this.prenom);
        for(CompteBancaire c : listeComptes) {
            System.out.println(c.Decrire());
        }
    }
}