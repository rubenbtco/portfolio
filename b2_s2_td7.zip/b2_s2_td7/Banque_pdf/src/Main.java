public class Main {
    public static void main(String[] args) {
        Client c1 = new Client("Gravouil", "Benjamin", 1, "02/05/1977", "enseignant", "lycée Paul Lapie, 5 boulevard AB, 92400 COURBEVOIE", "01.01.01.01.01", "prof.gravouil@gmail.com");

        CompteCourant compte1 = new CompteCourant("13245411324", c1, 2548200, "€", "1234", 1000);
        CompteEpargne compte2 = new CompteEpargne("32544771289", c1, 1000, "€", 0.05);
        CompteCourant compte3 = new CompteCourant("22544771289", c1, -214, "€", "5678", 500);

        c1.ajouterCompte(compte1);
        c1.ajouterCompte(compte2);
        c1.ajouterCompte(compte3);

        c1.info_comptes();

        compte3.crediter(100);
        compte2.ajouter_interet();

        System.out.println("\n--- Après opérations ---");
        c1.info_comptes();
    }
}