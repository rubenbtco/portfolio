public class CompteEpargne extends CompteBancaire {
    private double taux;

    public CompteEpargne(String numero, Client titulaire, double solde, String devise, double taux) {
        super(numero, titulaire, solde, devise);
        this.taux = taux;
    }

    @Override
    public String Decrire() {
        int tauxPourcentage = (int)(this.taux * 100);
        return "Compte Epargne " + super.Decrire() + " - taux = " + tauxPourcentage + "%";
    }

    public void ajouter_interet() {
        if(this.solde > 0) {
            this.solde += (this.solde * this.taux);
        }
    }

    @Override
    public void debiter(double montant) {
        if (montant > 0 && montant <= (this.solde / 2)) {
            this.solde -= montant;
        } else {
            System.out.println("Retrait refusé.");
        }
    }
}