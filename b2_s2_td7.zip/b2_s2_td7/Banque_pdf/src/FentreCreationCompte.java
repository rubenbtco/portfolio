import javax.swing.*;
import java.awt.*;

public class FenetreCreationCompte extends JFrame {

    private JComboBox<String> comboClients;
    private JRadioButton radioCourant;
    private JRadioButton radioEpargne;
    private JTextField txtCB;
    private JTextField txtDecouvert;
    private JTextField txtSolde;
    private JTextField txtTaux;
    private JButton btnCreer;

    public FenetreCreationCompte() {
        setTitle("Création de Compte");
        setSize(500, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        JLabel lblClient = new JLabel("Sélectionner Client :");
        lblClient.setBounds(20, 20, 150, 25);
        add(lblClient);

        comboClients = new JComboBox<>(new String[]{"1211454512 - GRAVOUIL", "4446455544 - DINDAR"});
        comboClients.setBounds(180, 20, 250, 25);
        add(comboClients);

        JLabel lblType = new JLabel("Type de compte :");
        lblType.setBounds(20, 70, 150, 25);
        add(lblType);

        radioCourant = new JRadioButton("Compte Courant");
        radioCourant.setBounds(180, 70, 130, 25);
        radioEpargne = new JRadioButton("Compte Epargne");
        radioEpargne.setBounds(310, 70, 130, 25);

        ButtonGroup bg = new ButtonGroup();
        bg.add(radioCourant);
        bg.add(radioEpargne);
        add(radioCourant);
        add(radioEpargne);

        JLabel lblCB = new JLabel("n° CB :");
        lblCB.setBounds(20, 110, 100, 25);
        add(lblCB);
        txtCB = new JTextField();
        txtCB.setBounds(120, 110, 100, 25);
        add(txtCB);

        JLabel lblDecouvert = new JLabel("Découvert Max :");
        lblDecouvert.setBounds(20, 150, 100, 25);
        add(lblDecouvert);
        txtDecouvert = new JTextField();
        txtDecouvert.setBounds(120, 150, 100, 25);
        add(txtDecouvert);

        JLabel lblSolde = new JLabel("SOLDE :");
        lblSolde.setBounds(20, 190, 100, 25);
        add(lblSolde);
        txtSolde = new JTextField();
        txtSolde.setBounds(120, 190, 100, 25);
        add(txtSolde);

        JLabel lblTaux = new JLabel("Taux :");
        lblTaux.setBounds(250, 150, 50, 25);
        add(lblTaux);
        txtTaux = new JTextField();
        txtTaux.setBounds(300, 150, 100, 25);
        add(txtTaux);

        btnCreer = new JButton("CREER");
        btnCreer.setBounds(200, 220, 100, 30);
        add(btnCreer);
    }
}