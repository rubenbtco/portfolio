public class CompteCourant extends CompteBancaire {
    private String numeroCB;
    private double decouvertMaximal;

    public CompteCourant(String numero, Client titulaire, double solde, String devise, String numeroCB, double decouvertMaximal) {
        super(numero, titulaire, solde, devise);
        this.numeroCB = numeroCB;
        this.decouvertMaximal = decouvertMaximal;
    }

    @Override
    public void debiter(double montant) {
        if (montant > 0 && (this.solde - montant) >= -this.decouvertMaximal) {
            this.solde -= montant;
        } else {
            System.out.println("Retrait refusé.");
        }
    }

    @Override
    public String Decrire() {
        return "Compte Courant " + super.Decrire() + " - CB : " + this.numeroCB;
    }
}