<?php
$a=2;
$a=$a-1;
$a++;
$b=8;
$b+=2;
$c=$a+$b*$b;
$d=$a*$b+$b;
$e=$a*($b+$b);
$f=$a*$b/$a;
$g=$b/$a*$a;

echo "Valeurs finales : <br>";
echo "a = $a <br> b = $b <br> c = $c <br> d = $d <br> e = $e <br> f = $f <br> g = $g";
?>