//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import java.util.ArrayList;

public class Main { // Attention à la majuscule ici pour correspondre à votre fichier

    public static void main(String[] args) {
        // Question 1 : Création de l'ArrayList
        ArrayList<Livre> listeDeLivres = new ArrayList<Livre>();

        // Création des livres
        Livre livre1 = new Livre("1111111", "Harry Potter", "JK Rowling", 20);
        Livre livre2 = new Livre("2222222", "Seigneur des Anneaux", "Tolkien", 30);

        // Question 2 : Ajout de 2 autres livres
        Livre livre3 = new Livre("3333333", "Les Misérables", "Victor Hugo", 15);
        Livre livre4 = new Livre("4444444", "Dune", "Frank Herbert", 25);

        // Ajout des livres dans la liste
        listeDeLivres.add(livre1);
        listeDeLivres.add(livre2);
        listeDeLivres.add(livre3);
        listeDeLivres.add(livre4);

        // Question 3 : Affichage de l'ensemble des livres via une boucle
        System.out.println("--- LISTE DES LIVRES (Partie 1) ---");
        for (Livre l : listeDeLivres) {
            l.Afficher();
        }
    }
}