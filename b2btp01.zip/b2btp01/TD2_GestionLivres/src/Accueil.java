import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class Accueil extends JFrame {

    // Déclaration des composants graphiques
    private JTextField txtIsbn;
    private JTextField txtTitre;
    private JTextField txtPrix;
    private JLabel lblCompteur;

    // Question 5 : L'ArrayList pour stocker les livres
    private ArrayList<Livre> al = new ArrayList<Livre>();

    // Point d'entrée principal (Main) pour lancer l'application
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Accueil frame = new Accueil();
                    frame.setVisible(true); // Rend la fenêtre visible
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    // Constructeur de la fenêtre
    public Accueil() {
        // Configuration de la fenêtre principale
        setTitle("Accueil");
        setBounds(100, 100, 500, 350); // Taille de la fenêtre
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Quitte l'appli quand on ferme
        getContentPane().setLayout(null); // Pas de mise en page automatique (pour placer au pixel près)

        // Question 6 : Initialisation des livres de départ
        al.add(new Livre("1111111", "Harry Potter", "JK Rowling", 20));
        al.add(new Livre("2222222", "Le Seigneur des Anneaux", "Tolkien", 30));
        al.add(new Livre("3333333", "Misérables", "Hugo", 15));
        al.add(new Livre("4444444", "Dune", "Herbert", 25));

        // --- CRÉATION DE L'INTERFACE (Question 7) ---

        // Ligne 1 : ISBN
        JLabel lblIsbn = new JLabel("ISBN DU LIVRE");
        lblIsbn.setBounds(20, 30, 120, 25);
        getContentPane().add(lblIsbn);

        txtIsbn = new JTextField();
        txtIsbn.setBounds(150, 30, 150, 25);
        getContentPane().add(txtIsbn);

        // Bouton Rechercher (à droite de l'ISBN)
        JButton btnRechercher = new JButton("Rechercher");
        btnRechercher.setBounds(320, 30, 120, 25);
        getContentPane().add(btnRechercher);

        // Ligne 2 : Titre
        JLabel lblTitre = new JLabel("TITRE DU LIVRE");
        lblTitre.setBounds(20, 70, 120, 25);
        getContentPane().add(lblTitre);

        txtTitre = new JTextField();
        txtTitre.setBounds(150, 70, 150, 25);
        getContentPane().add(txtTitre);

        // Ligne 3 : Prix
        JLabel lblPrix = new JLabel("PRIX DU LIVRE");
        lblPrix.setBounds(20, 110, 120, 25);
        getContentPane().add(lblPrix);

        txtPrix = new JTextField();
        txtPrix.setBounds(150, 110, 150, 25);
        getContentPane().add(txtPrix);

        // Bouton Ajouter
        JButton btnAjouter = new JButton("AJOUTER");
        btnAjouter.setBounds(150, 160, 150, 40);
        getContentPane().add(btnAjouter);

        // Compteur de livres
        lblCompteur = new JLabel("Nombre de livre : 0");
        lblCompteur.setBounds(100, 220, 200, 25);
        getContentPane().add(lblCompteur);

        // Mettre à jour le compteur au démarrage
        actualiserCompteur();

        // --- ACTIONS DES BOUTONS ---

        // Action du bouton AJOUTER
        btnAjouter.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    String isbn = txtIsbn.getText();
                    String titre = txtTitre.getText();
                    // Conversion du String en int comme demandé [cite: 1639]
                    int prix = Integer.parseInt(txtPrix.getText());

                    // Création et ajout du livre
                    Livre nouveauLivre = new Livre(isbn, titre, "Inconnu", prix);
                    al.add(nouveauLivre);

                    // Mise à jour de l'affichage
                    actualiserCompteur();
                    JOptionPane.showMessageDialog(null, "Livre ajouté !");

                    // Vider les champs
                    txtIsbn.setText("");
                    txtTitre.setText("");
                    txtPrix.setText("");

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Erreur : Le prix doit être un nombre entier !");
                }
            }
        });

        // Action du bouton RECHERCHER
        btnRechercher.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String isbnRecherche = txtIsbn.getText();
                boolean trouve = false;

                // Parcours de l'ArrayList
                for (Livre l : al) {
                    if (l.getISBN().equals(isbnRecherche)) {
                        txtTitre.setText(l.getTitre());
                        // Conversion int vers String comme demandé [cite: 1639]
                        txtPrix.setText(String.valueOf(l.getPrix()));
                        trouve = true;
                        break; // On arrête la boucle si on a trouvé
                    }
                }

                if (!trouve) {
                    txtTitre.setText("ERREUR");
                    txtPrix.setText("ERREUR");
                }
            }
        });
    }

    // Petite méthode pour mettre à jour le texte du compteur
    private void actualiserCompteur() {
        lblCompteur.setText("Nombre de livre : " + al.size());
    }
}