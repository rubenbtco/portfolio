public class Livre {
    private String ISBN, titre, Auteur;
    private int prix;

    // Constructeur du livre
    public Livre(String ISBN, String titre, String auteur, int prix) {
        this.ISBN = ISBN;
        this.titre = titre;
        this.Auteur = auteur;
        this.prix = prix;
    }

    // Début des GET et SET
    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public String getAuteur() {
        return Auteur;
    }

    public void setAuteur(String auteur) {
        Auteur = auteur;
    }

    public int getPrix() {
        return prix;
    }

    public void setPrix(int prix) {
        this.prix = prix;
    }

    public String getISBN() {
        return ISBN;
    }

    public void setISBN(String iSBN) {
        ISBN = iSBN;
    }

    // Fonction d'affichage (demandée dans le TD question 3)
    public void Afficher() {
        System.out.print("Titre: " + titre + ", ");
        System.out.print("Auteur: " + Auteur + ", ");
        System.out.println("Prix: " + prix + "€");
    }
}