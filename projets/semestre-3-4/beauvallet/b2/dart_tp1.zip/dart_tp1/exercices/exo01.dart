import 'dart:io';

void main() {
  stdout.write('Quel est votre nom ? ');
  String nom = stdin.readLineSync()!;
  stdout.write('Quel est votre âge ? ');
  int age = int.parse(stdin.readLineSync()!);

  int reste = 100 - age;
  print('$nom, vous aurez 100 ans dans $reste ans.');
}
