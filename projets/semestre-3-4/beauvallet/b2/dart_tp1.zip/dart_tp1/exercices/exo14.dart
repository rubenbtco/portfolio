import 'dart:io';

String inverserMots(String phrase) {
  return phrase.split(' ').reversed.join(' ');
}

void main() {
  stdout.write('Entrez une phrase : ');
  String phrase = stdin.readLineSync()!;
  print(inverserMots(phrase));
}
