int gagnant(List<List<int>> jeu) {
  for (int i = 0; i < 3; i++) {
    if (jeu[i][0] != 0 && jeu[i][0] == jeu[i][1] && jeu[i][1] == jeu[i][2]) {
      return jeu[i][0];
    }
    if (jeu[0][i] != 0 && jeu[0][i] == jeu[1][i] && jeu[1][i] == jeu[2][i]) {
      return jeu[0][i];
    }
  }
  if (jeu[1][1] != 0) {
    if (jeu[0][0] == jeu[1][1] && jeu[1][1] == jeu[2][2]) {
      return jeu[1][1];
    }
    if (jeu[0][2] == jeu[1][1] && jeu[1][1] == jeu[2][0]) {
      return jeu[1][1];
    }
  }
  return 0;
}

void afficherResultat(List<List<int>> jeu) {
  for (List<int> ligne in jeu) {
    print(ligne);
  }
  int resultat = gagnant(jeu);
  if (resultat == 0) {
    print('Personne n\'a gagné.\n');
  } else {
    print('Le joueur $resultat a gagné.\n');
  }
}

void main() {
  afficherResultat([
    [1, 2, 0],
    [2, 1, 0],
    [2, 1, 1],
  ]);
  afficherResultat([
    [2, 2, 2],
    [1, 1, 0],
    [0, 1, 0],
  ]);
  afficherResultat([
    [1, 2, 1],
    [2, 1, 2],
    [2, 1, 2],
  ]);
}
