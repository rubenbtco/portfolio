import 'dart:io';
import 'dart:math';

void main() {
  Random alea = Random();
  String secret = '';
  for (int i = 0; i < 4; i++) {
    secret += alea.nextInt(10).toString();
  }

  int essais = 0;
  print('J\'ai choisi un nombre à 4 chiffres.');
  while (true) {
    stdout.write('Votre proposition : ');
    String proposition = stdin.readLineSync()!;
    if (proposition.length != 4) {
      print('Il faut 4 chiffres.');
      continue;
    }
    essais++;

    int vaches = 0;
    int taureaux = 0;
    List<String> resteSecret = [];
    List<String> resteProposition = [];
    for (int i = 0; i < 4; i++) {
      if (proposition[i] == secret[i]) {
        vaches++;
      } else {
        resteSecret.add(secret[i]);
        resteProposition.add(proposition[i]);
      }
    }
    for (String chiffre in resteProposition) {
      if (resteSecret.contains(chiffre)) {
        taureaux++;
        resteSecret.remove(chiffre);
      }
    }

    print('$vaches vache(s), $taureaux taureau(x)');
    if (vaches == 4) {
      print('Bravo ! Vous avez trouvé $secret en $essais essais.');
      break;
    }
  }
}
