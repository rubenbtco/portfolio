import 'dart:io';

void afficherPlateau(List<List<String>> plateau) {
  for (List<String> ligne in plateau) {
    print(' --- --- ---');
    print('| ${ligne[0]} | ${ligne[1]} | ${ligne[2]} |');
  }
  print(' --- --- ---');
}

String gagnant(List<List<String>> p) {
  for (int i = 0; i < 3; i++) {
    if (p[i][0] != ' ' && p[i][0] == p[i][1] && p[i][1] == p[i][2]) {
      return p[i][0];
    }
    if (p[0][i] != ' ' && p[0][i] == p[1][i] && p[1][i] == p[2][i]) {
      return p[0][i];
    }
  }
  if (p[1][1] != ' ') {
    if (p[0][0] == p[1][1] && p[1][1] == p[2][2]) {
      return p[1][1];
    }
    if (p[0][2] == p[1][1] && p[1][1] == p[2][0]) {
      return p[1][1];
    }
  }
  return ' ';
}

bool jouer(List<List<String>> plateau, String joueur) {
  stdout.write('Joueur $joueur, où voulez-vous jouer (ligne,colonne) ? ');
  List<String> coordonnees = stdin.readLineSync()!.split(',');
  int ligne = int.parse(coordonnees[0]) - 1;
  int colonne = int.parse(coordonnees[1]) - 1;

  if (plateau[ligne][colonne] != ' ') {
    print('Cette case est déjà prise.');
    return false;
  }
  plateau[ligne][colonne] = joueur;
  return true;
}

void main() {
  List<List<String>> plateau = [
    [' ', ' ', ' '],
    [' ', ' ', ' '],
    [' ', ' ', ' '],
  ];
  String joueur = 'X';
  int coups = 0;

  afficherPlateau(plateau);
  while (coups < 9) {
    if (!jouer(plateau, joueur)) {
      continue;
    }
    coups++;
    afficherPlateau(plateau);

    if (gagnant(plateau) != ' ') {
      print('Félicitations, le joueur $joueur a gagné !');
      return;
    }
    joueur = (joueur == 'X') ? 'O' : 'X';
  }
  print('Match nul, il ne reste plus de coup.');
}
