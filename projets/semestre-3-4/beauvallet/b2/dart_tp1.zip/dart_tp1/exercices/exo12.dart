import 'dart:io';

List<int> fibonacci(int n) {
  List<int> suite = [];
  int a = 1;
  int b = 1;
  for (int i = 0; i < n; i++) {
    suite.add(a);
    int suivant = a + b;
    a = b;
    b = suivant;
  }
  return suite;
}

void main() {
  stdout.write('Combien de nombres de Fibonacci voulez-vous ? ');
  int n = int.parse(stdin.readLineSync()!);
  print(fibonacci(n));
}
