int plusGrand(int a, int b, int c) {
  int resultat = a;
  if (b > resultat) {
    resultat = b;
  }
  if (c > resultat) {
    resultat = c;
  }
  return resultat;
}

void main() {
  print('Le plus grand de 4, 12 et 7 est ${plusGrand(4, 12, 7)}');
  print('Le plus grand de 25, 3 et 18 est ${plusGrand(25, 3, 18)}');
  print('Le plus grand de 5, 5 et 9 est ${plusGrand(5, 5, 9)}');
}
