import 'dart:io';

void afficherPlateau(List<List<String>> plateau) {
  for (List<String> ligne in plateau) {
    print(' --- --- ---');
    print('| ${ligne[0]} | ${ligne[1]} | ${ligne[2]} |');
  }
  print(' --- --- ---');
}

void main() {
  List<List<String>> plateau = [
    [' ', ' ', ' '],
    [' ', ' ', ' '],
    [' ', ' ', ' '],
  ];
  afficherPlateau(plateau);

  stdout.write('Joueur X, où voulez-vous jouer (ligne,colonne) ? ');
  List<String> coordonnees = stdin.readLineSync()!.split(',');
  int ligne = int.parse(coordonnees[0]) - 1;
  int colonne = int.parse(coordonnees[1]) - 1;

  if (plateau[ligne][colonne] == ' ') {
    plateau[ligne][colonne] = 'X';
  } else {
    print('Cette case est déjà prise.');
  }
  afficherPlateau(plateau);
}
