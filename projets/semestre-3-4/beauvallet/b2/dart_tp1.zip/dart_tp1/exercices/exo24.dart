import 'dart:io';

String motAffiche(String mot, List<String> lettres) {
  String resultat = '';
  for (String lettre in mot.split('')) {
    resultat += lettres.contains(lettre) ? '$lettre ' : '_ ';
  }
  return resultat;
}

void main() {
  String mot = 'EVAPORATE';
  List<String> lettres = [];

  print('Bienvenue au Pendu !');
  print(motAffiche(mot, lettres));
  while (motAffiche(mot, lettres).contains('_')) {
    stdout.write('Devinez une lettre : ');
    String lettre = stdin.readLineSync()!.toUpperCase();

    if (lettres.contains(lettre)) {
      print('Vous avez déjà proposé la lettre $lettre.');
    } else {
      lettres.add(lettre);
      if (!mot.contains(lettre)) {
        print('Raté !');
      }
    }
    print(motAffiche(mot, lettres));
  }
  print('Bravo, vous avez trouvé le mot $mot !');
}
