import 'dart:io';
import 'dart:math';

List<String> dessins = [
  '''
  +---+
  |   |
      |
      |
      |
=======''',
  '''
  +---+
  |   |
  O   |
      |
      |
=======''',
  '''
  +---+
  |   |
  O   |
  |   |
      |
=======''',
  '''
  +---+
  |   |
  O   |
 /|   |
      |
=======''',
  '''
  +---+
  |   |
  O   |
 /|\\  |
      |
=======''',
  '''
  +---+
  |   |
  O   |
 /|\\  |
 /    |
=======''',
  '''
  +---+
  |   |
  O   |
 /|\\  |
 / \\  |
=======''',
];

String motAuHasard() {
  List<String> mots = File('sowpods.txt').readAsLinesSync();
  return mots[Random().nextInt(mots.length)];
}

String motAffiche(String mot, List<String> lettres) {
  String resultat = '';
  for (String lettre in mot.split('')) {
    resultat += lettres.contains(lettre) ? '$lettre ' : '_ ';
  }
  return resultat;
}

void partie() {
  String mot = motAuHasard();
  List<String> lettres = [];
  int erreurs = 0;

  print(motAffiche(mot, lettres));
  while (erreurs < 6 && motAffiche(mot, lettres).contains('_')) {
    stdout.write('Devinez une lettre : ');
    String lettre = stdin.readLineSync()!.toUpperCase();

    if (lettres.contains(lettre)) {
      print('Vous avez déjà proposé la lettre $lettre, rejouez.');
      continue;
    }
    lettres.add(lettre);
    if (!mot.contains(lettre)) {
      erreurs++;
      print(dessins[erreurs]);
      print('Raté ! Il vous reste ${6 - erreurs} erreur(s).');
    }
    print(motAffiche(mot, lettres));
  }

  if (erreurs == 6) {
    print('Perdu ! Le mot était $mot.');
  } else {
    print('Bravo, vous avez trouvé le mot $mot !');
  }
}

void main() {
  print('Bienvenue au Pendu !');
  String rejouer = 'o';
  while (rejouer == 'o') {
    partie();
    stdout.write('Voulez-vous rejouer ? (o/n) ');
    rejouer = stdin.readLineSync()!.toLowerCase();
  }
}
