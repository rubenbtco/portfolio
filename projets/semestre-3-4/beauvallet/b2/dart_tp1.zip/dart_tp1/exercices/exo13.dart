List<int> sansDoublons(List<int> liste) {
  return liste.toSet().toList();
}

void main() {
  List<int> a = [1, 1, 2, 3, 5, 8, 8, 13, 21, 21, 34, 5];
  print('Liste de départ : $a');
  print('Sans doublons : ${sansDoublons(a)}');
}
