import 'dart:io';
import 'dart:math';

Random alea = Random();

String motDePasseFaible() {
  List<String> mots = ['soleil', 'chat', 'maison', 'velo', 'pomme', 'montagne'];
  return mots[alea.nextInt(mots.length)] + mots[alea.nextInt(mots.length)];
}

String motDePasseFort(int longueur) {
  String caracteres = 'abcdefghijklmnopqrstuvwxyz'
      'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
      '0123456789'
      '!@#\$%&*?-_';
  String resultat = '';
  for (int i = 0; i < longueur; i++) {
    resultat += caracteres[alea.nextInt(caracteres.length)];
  }
  return resultat;
}

void main() {
  stdout.write('Mot de passe faible, moyen ou fort ? ');
  String force = stdin.readLineSync()!.toLowerCase();

  if (force == 'faible') {
    print('Mot de passe : ${motDePasseFaible()}');
  } else if (force == 'moyen') {
    print('Mot de passe : ${motDePasseFort(8)}');
  } else {
    print('Mot de passe : ${motDePasseFort(16)}');
  }
}
