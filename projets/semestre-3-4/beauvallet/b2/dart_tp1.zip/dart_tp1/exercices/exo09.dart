import 'dart:io';
import 'dart:math';

void main() {
  int secret = Random().nextInt(100) + 1;
  int essais = 0;
  int proposition = 0;

  print('J\'ai choisi un nombre entre 1 et 100.');
  while (proposition != secret) {
    stdout.write('Votre proposition : ');
    proposition = int.parse(stdin.readLineSync()!);
    essais++;

    if (proposition < secret) {
      print('Trop bas.');
    } else if (proposition > secret) {
      print('Trop haut.');
    } else {
      print('Exactement ! Vous avez trouvé en $essais essais.');
    }
  }
}
