import 'dart:io';

void dessinerPlateau(int taille) {
  String ligneHaut = ' ---' * taille;
  String ligneCases = '|   ' * taille + '|';

  for (int i = 0; i < taille; i++) {
    print(ligneHaut);
    print(ligneCases);
  }
  print(ligneHaut);
}

void main() {
  stdout.write('Quelle taille de plateau ? ');
  int taille = int.parse(stdin.readLineSync()!);
  dessinerPlateau(taille);
}
