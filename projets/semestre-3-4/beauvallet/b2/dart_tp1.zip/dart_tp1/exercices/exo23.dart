import 'dart:io';
import 'dart:math';

String motAuHasard() {
  List<String> mots = File('sowpods.txt').readAsLinesSync();
  return mots[Random().nextInt(mots.length)];
}

void main() {
  print('Mot choisi au hasard : ${motAuHasard()}');
  print('Mot choisi au hasard : ${motAuHasard()}');
  print('Mot choisi au hasard : ${motAuHasard()}');
}
