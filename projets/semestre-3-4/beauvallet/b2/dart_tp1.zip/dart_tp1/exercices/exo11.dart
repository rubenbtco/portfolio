List<int> premierEtDernier(List<int> liste) {
  return [liste.first, liste.last];
}

void main() {
  List<int> a = [5, 10, 15, 20, 25];
  print('Liste de départ : $a');
  print('Premier et dernier : ${premierEtDernier(a)}');
}
