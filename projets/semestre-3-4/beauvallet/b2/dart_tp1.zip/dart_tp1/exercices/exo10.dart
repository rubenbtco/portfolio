import 'dart:io';

bool estPremier(int nombre) {
  if (nombre < 2) {
    return false;
  }
  for (int i = 2; i * i <= nombre; i++) {
    if (nombre % i == 0) {
      return false;
    }
  }
  return true;
}

void main() {
  stdout.write('Entrez un nombre : ');
  int nombre = int.parse(stdin.readLineSync()!);

  if (estPremier(nombre)) {
    print('$nombre est un nombre premier.');
  } else {
    print('$nombre n\'est pas un nombre premier.');
  }
}
