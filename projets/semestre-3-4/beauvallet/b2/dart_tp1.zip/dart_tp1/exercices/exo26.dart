import 'dart:io';

void main() {
  Map<String, String> anniversaires = {
    'Albert Einstein': '14/03/1879',
    'Benjamin Franklin': '17/01/1706',
    'Ada Lovelace': '10/12/1815',
  };

  print('>>> Bienvenue dans le dictionnaire d\'anniversaire. '
      'Nous connaissons les dates d\'anniversaire de :');
  for (String nom in anniversaires.keys) {
    print(nom);
  }

  print('>>> De qui voulez-vous connaître la date d\'anniversaire ?');
  String nom = stdin.readLineSync()!;

  if (anniversaires.containsKey(nom)) {
    print('>>> $nom est né le ${anniversaires[nom]}.');
  } else {
    print('>>> Désolé, nous ne connaissons pas l\'anniversaire de $nom.');
  }
}
