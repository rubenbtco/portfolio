import 'dart:io';

void main() {
  int min = 0;
  int max = 100;
  int essais = 0;

  print('Pensez à un nombre entre 0 et 100.');
  while (true) {
    int proposition = (min + max) ~/ 2;
    essais++;
    stdout.write('Est-ce $proposition ? (haut / bas / oui) ');
    String reponse = stdin.readLineSync()!.toLowerCase();

    if (reponse == 'oui') {
      print('J\'ai trouvé votre nombre en $essais essais.');
      break;
    } else if (reponse == 'haut') {
      max = proposition - 1;
    } else if (reponse == 'bas') {
      min = proposition + 1;
    }
  }
}
