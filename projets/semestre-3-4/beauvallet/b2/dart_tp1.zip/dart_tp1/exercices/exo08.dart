import 'dart:io';
import 'dart:math';

void main() {
  List<String> choix = ['pierre', 'papier', 'ciseaux'];

  stdout.write('Pierre, papier ou ciseaux ? ');
  String joueur = stdin.readLineSync()!.toLowerCase();
  if (!choix.contains(joueur)) {
    print('Choix invalide.');
    return;
  }

  String ordinateur = choix[Random().nextInt(3)];
  print('L\'ordinateur a joué : $ordinateur');

  if (joueur == ordinateur) {
    print('Égalité !');
  } else if ((joueur == 'pierre' && ordinateur == 'ciseaux') ||
      (joueur == 'papier' && ordinateur == 'pierre') ||
      (joueur == 'ciseaux' && ordinateur == 'papier')) {
    print('Bravo, vous avez gagné !');
  } else {
    print('L\'ordinateur a gagné.');
  }
}
