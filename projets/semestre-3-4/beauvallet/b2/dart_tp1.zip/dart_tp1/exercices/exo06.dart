import 'dart:io';

void main() {
  stdout.write('Entrez un mot : ');
  String mot = stdin.readLineSync()!.toLowerCase();

  String inverse = mot.split('').reversed.join();
  if (mot == inverse) {
    print('"$mot" est un palindrome.');
  } else {
    print('"$mot" n\'est pas un palindrome.');
  }
}
