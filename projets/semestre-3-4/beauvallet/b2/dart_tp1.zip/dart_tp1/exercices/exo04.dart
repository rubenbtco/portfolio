import 'dart:io';

void main() {
  stdout.write('Entrez un nombre : ');
  int nombre = int.parse(stdin.readLineSync()!);

  List<int> diviseurs = [];
  for (int i = 1; i <= nombre; i++) {
    if (nombre % i == 0) {
      diviseurs.add(i);
    }
  }
  print('Les diviseurs de $nombre sont : $diviseurs');
}
