import 'dart:io';

void main() {
  stdout.write('Entrez un nombre : ');
  int nombre = int.parse(stdin.readLineSync()!);

  if (nombre % 2 == 0) {
    print('$nombre est un nombre pair.');
  } else {
    print('$nombre est un nombre impair.');
  }
}
