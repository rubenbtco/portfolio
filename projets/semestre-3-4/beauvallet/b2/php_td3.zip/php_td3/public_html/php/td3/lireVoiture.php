<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title> Liste des voitures </title>
    </head>

    <body>
        <h2>Liste des voitures :</h2>
        <?php
          require_once 'Voiture.php';

          $tab_voit = Voiture::getAllVoitures();
          foreach ($tab_voit as $voiture) {
              $voiture->afficher();
          }

          echo "<h2>Recherche par immatriculation :</h2>";
          $voiture = Voiture::getVoitureByImmat('256AB34');
          if ($voiture == false) {
              echo "<p>Aucune voiture trouvée.</p>";
          } else {
              $voiture->afficher();
          }

          $voiture = Voiture::getVoitureByImmat('AAAAAAAA');
          if ($voiture == false) {
              echo "<p>Aucune voiture trouvée.</p>";
          } else {
              $voiture->afficher();
          }
        ?>
    </body>
</html>
