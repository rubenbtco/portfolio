<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title> Désinscription d'un passager </title>
    </head>

    <body>
        <form method="get" action="testDelPassager.php">
          <fieldset>
            <legend>Désinscrire un passager :</legend>
            <p>
              <label for="trajet_id">Identifiant du trajet</label> :
              <input type="text" placeholder="Ex : 1" name="trajet_id" id="trajet_id" required/>
            </p>
            <p>
              <label for="login_id">Login de l'utilisateur</label> :
              <input type="text" placeholder="Ex : mdupont" name="utilisateur_login" id="login_id" required/>
            </p>
            <p>
              <input type="submit" value="Envoyer" />
            </p>
          </fieldset>
        </form>
    </body>
</html>
