<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title> Injection SQL </title>
    </head>

    <body>
        <form method="get" action="formGetImmatSQL.php">
          <fieldset>
            <legend>Rechercher une voiture :</legend>
            <p>
              <label for="immat_id">Immatriculation</label> :
              <input type="text" placeholder="Ex : 256AB34" name="immatriculation" id="immat_id" size="50" required/>
            </p>
            <p>
              <input type="submit" value="Envoyer" />
            </p>
          </fieldset>
        </form>

        <?php
          require_once 'Voiture.php';

          // version volontairement vulnerable : pas de requete preparee
          function getVoitureByImmat($immat) {
            $sql = "SELECT * from voiture2 WHERE immatriculation='$immat'";
            echo "<p>Requête exécutée : <code>" . htmlspecialchars($sql) . "</code></p>";
            $rep = Model::$pdo->query($sql);
            $rep->setFetchMode(PDO::FETCH_CLASS, 'Voiture');
            return $rep->fetch();
          }

          if (isset($_GET['immatriculation'])) {
              $voiture = getVoitureByImmat($_GET['immatriculation']);
              if ($voiture == false) {
                  echo "<p>Aucune voiture trouvée.</p>";
              } else {
                  $voiture->afficher();
              }
          }
        ?>
    </body>
</html>
