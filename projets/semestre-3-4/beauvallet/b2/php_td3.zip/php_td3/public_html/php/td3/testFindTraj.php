<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title> Trajets d'un utilisateur </title>
    </head>

    <body>
        <?php
          require_once 'Utilisateur.php';
          require_once 'Trajet.php';

          if (!isset($_GET['login'])) {
              echo "<p>Aucun login reçu.</p>";
          } else {
              $login = htmlspecialchars($_GET['login']);
              echo "<h2>Trajets de {$login} en tant que passager :</h2>";
              $tab_traj = Utilisateur::findTrajets($_GET['login']);
              if (empty($tab_traj)) {
                  echo "<p>Aucun trajet pour cet utilisateur.</p>";
              }
              foreach ($tab_traj as $trajet) {
                  $trajet->afficher();
              }
          }
        ?>
    </body>
</html>
