<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title> Trajets d'un utilisateur </title>
    </head>

    <body>
        <form method="get" action="testFindTraj.php">
          <fieldset>
            <legend>Trajets d'un utilisateur :</legend>
            <p>
              <label for="login_id">Login de l'utilisateur</label> :
              <input type="text" placeholder="Ex : mdupont" name="login" id="login_id" required/>
            </p>
            <p>
              <input type="submit" value="Envoyer" />
            </p>
          </fieldset>
        </form>
    </body>
</html>
