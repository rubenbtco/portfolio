<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title> Désinscription d'un passager </title>
    </head>

    <body>
        <?php
          require_once 'Utilisateur.php';
          require_once 'Trajet.php';

          if (!isset($_GET['trajet_id'], $_GET['utilisateur_login'])) {
              echo "<p>Aucune information reçue.</p>";
          } else {
              $id = htmlspecialchars($_GET['trajet_id']);
              $login = htmlspecialchars($_GET['utilisateur_login']);
              $nb = Trajet::deletePassager($_GET);
              if ($nb == 0) {
                  echo "<p>{$login} n'était pas inscrit au trajet n°{$id}.</p>";
              } else {
                  echo "<p>{$login} a été désinscrit du trajet n°{$id}.</p>";
              }

              echo "<h2>Passagers restants du trajet n°{$id} :</h2>";
              foreach (Trajet::findPassagers($_GET['trajet_id']) as $utilisateur) {
                  $utilisateur->afficher();
              }
          }
        ?>
    </body>
</html>
