CREATE TABLE IF NOT EXISTS voiture2 (
  immatriculation VARCHAR(8) NOT NULL,
  marque VARCHAR(25) DEFAULT NULL,
  couleur VARCHAR(12) DEFAULT NULL,
  PRIMARY KEY (immatriculation)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO voiture2 (immatriculation, marque, couleur) VALUES
('123XY456', 'Peugeot', 'rouge'),
('256AB34', 'Renault', 'bleu'),
('789CD012', 'Citroën', 'vert');
