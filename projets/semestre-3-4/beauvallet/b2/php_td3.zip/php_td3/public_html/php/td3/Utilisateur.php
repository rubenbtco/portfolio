<?php
require_once 'Model.php';

class Utilisateur {

  private $login;
  private $nom;
  private $prenom;

  public function get($nom_attribut) {
       return $this->$nom_attribut;
  }

  public function set($nom_attribut, $valeur) {
       $this->$nom_attribut = $valeur;
  }

  public function __construct($data = NULL) {
    if (!is_null($data)) {
      foreach ($data as $cle => $valeur) {
        $this->set($cle, $valeur);
      }
    }
  }

  public function afficher() {
    $login = htmlspecialchars($this->login);
    $nom = htmlspecialchars($this->nom);
    $prenom = htmlspecialchars($this->prenom);
    echo "<p> Utilisateur {$login} : {$prenom} {$nom} </p>";
  }

  public static function getAllUtilisateurs() {
    try {
      $rep = Model::$pdo->query("SELECT * FROM utilisateur");
      $rep->setFetchMode(PDO::FETCH_CLASS, 'Utilisateur');
      return $rep->fetchAll();
    } catch (PDOException $e) {
      if (Conf::getDebug()) {
        echo $e->getMessage();
      } else {
        echo 'Une erreur est survenue <a href=""> retour a la page d\'accueil </a>';
      }
      die();
    }
  }

  public static function findTrajets($login) {
    try {
      $sql = "SELECT t.* FROM trajet t
              INNER JOIN passager p ON p.trajet_id = t.id
              WHERE p.utilisateur_login = :login";
      $req_prep = Model::$pdo->prepare($sql);
      $req_prep->execute(array("login" => $login));
      $req_prep->setFetchMode(PDO::FETCH_CLASS, 'Trajet');
      return $req_prep->fetchAll();
    } catch (PDOException $e) {
      if (Conf::getDebug()) {
        echo $e->getMessage();
      } else {
        echo 'Une erreur est survenue <a href=""> retour a la page d\'accueil </a>';
      }
      die();
    }
  }
}
?>
