<?php
require_once 'Model.php';
require_once 'Utilisateur.php';

class Trajet {

  private $id;
  private $depart;
  private $arrivee;
  private $date;
  private $nbplaces;
  private $prix;
  private $conducteur_login;

  public function get($nom_attribut) {
       return $this->$nom_attribut;
  }

  public function set($nom_attribut, $valeur) {
       $this->$nom_attribut = $valeur;
  }

  public function __construct($data = NULL) {
    if (!is_null($data)) {
      foreach ($data as $cle => $valeur) {
        $this->set($cle, $valeur);
      }
    }
  }

  public function afficher() {
    $depart = htmlspecialchars($this->depart);
    $arrivee = htmlspecialchars($this->arrivee);
    $conducteur = htmlspecialchars($this->conducteur_login);
    echo "<p> Trajet n°{$this->id} de {$depart} à {$arrivee} le {$this->date} :"
       . " {$this->nbplaces} place(s) à {$this->prix} € (conducteur : {$conducteur}) </p>";
  }

  public static function getAllTrajets() {
    try {
      $rep = Model::$pdo->query("SELECT * FROM trajet");
      $rep->setFetchMode(PDO::FETCH_CLASS, 'Trajet');
      return $rep->fetchAll();
    } catch (PDOException $e) {
      if (Conf::getDebug()) {
        echo $e->getMessage();
      } else {
        echo 'Une erreur est survenue <a href=""> retour a la page d\'accueil </a>';
      }
      die();
    }
  }

  public static function findPassagers($id) {
    try {
      $sql = "SELECT u.* FROM utilisateur u
              INNER JOIN passager p ON p.utilisateur_login = u.login
              WHERE p.trajet_id = :id";
      $req_prep = Model::$pdo->prepare($sql);
      $req_prep->execute(array("id" => $id));
      $req_prep->setFetchMode(PDO::FETCH_CLASS, 'Utilisateur');
      return $req_prep->fetchAll();
    } catch (PDOException $e) {
      if (Conf::getDebug()) {
        echo $e->getMessage();
      } else {
        echo 'Une erreur est survenue <a href=""> retour a la page d\'accueil </a>';
      }
      die();
    }
  }

  // renvoie le nombre de lignes supprimees
  public static function deletePassager($data) {
    try {
      $sql = "DELETE FROM passager
              WHERE trajet_id = :trajet_id AND utilisateur_login = :utilisateur_login";
      $req_prep = Model::$pdo->prepare($sql);
      $values = array(
        "trajet_id" => $data['trajet_id'],
        "utilisateur_login" => $data['utilisateur_login'],
      );
      $req_prep->execute($values);
      return $req_prep->rowCount();
    } catch (PDOException $e) {
      if (Conf::getDebug()) {
        echo $e->getMessage();
      } else {
        echo 'Une erreur est survenue <a href=""> retour a la page d\'accueil </a>';
      }
      die();
    }
  }
}
?>
