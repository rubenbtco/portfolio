<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title> Passagers d'un trajet </title>
    </head>

    <body>
        <?php
          require_once 'Utilisateur.php';
          require_once 'Trajet.php';

          if (!isset($_GET['id'])) {
              echo "<p>Aucun identifiant de trajet reçu.</p>";
          } else {
              $id = htmlspecialchars($_GET['id']);
              echo "<h2>Passagers du trajet n°{$id} :</h2>";
              $tab_util = Trajet::findPassagers($_GET['id']);
              if (empty($tab_util)) {
                  echo "<p>Aucun passager pour ce trajet.</p>";
              }
              foreach ($tab_util as $utilisateur) {
                  $utilisateur->afficher();
              }
          }
        ?>
    </body>
</html>
