<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title> Passagers d'un trajet </title>
    </head>

    <body>
        <form method="get" action="testFindUtil.php">
          <fieldset>
            <legend>Passagers d'un trajet :</legend>
            <p>
              <label for="id_id">Identifiant du trajet</label> :
              <input type="text" placeholder="Ex : 1" name="id" id="id_id" required/>
            </p>
            <p>
              <input type="submit" value="Envoyer" />
            </p>
          </fieldset>
        </form>
    </body>
</html>
