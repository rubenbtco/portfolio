<?php
require_once File::build_path(array("model", "Model.php"));

class ModelVoiture {

  private $marque;
  private $couleur;
  private $immatriculation;

  // un getter
  public function getMarque() {
       return $this->marque;
  }

  // un setter
  public function setMarque($marque2) {
       $this->marque = $marque2;
  }

  public function getCouleur() {
       return $this->couleur;
  }

  public function setCouleur($couleur2) {
       $this->couleur = $couleur2;
  }

  public function getImmatriculation() {
       return $this->immatriculation;
  }

  // On limite l'immatriculation à 8 caractères
  public function setImmatriculation($immatriculation2) {
       if (strlen($immatriculation2) <= 8) {
           $this->immatriculation = $immatriculation2;
       } else {
           $this->immatriculation = substr($immatriculation2, 0, 8);
       }
  }

  // un constructeur
  // La syntaxe ... = NULL signifie que l'argument est optionel
  // Si un argument optionnel n'est pas fourni,
  // alors il prend la valeur par défaut, NULL dans notre cas
  public function __construct($m = NULL, $c = NULL, $i = NULL)  {
   if (!is_null($m) && !is_null($c) && !is_null($i)) {
     // Si aucun de $m, $c et $i sont nuls,
     // c'est forcement qu'on les a fournis
     // donc on retombe sur le constructeur à 3 arguments
     $this->marque = $m;
     $this->couleur = $c;
     $this->setImmatriculation($i);
   }
  }

  /*
  public function afficher() {
    $immatriculation = htmlspecialchars($this->immatriculation);
    $marque = htmlspecialchars($this->marque);
    $couleur = htmlspecialchars($this->couleur);
    echo "<p> Voiture {$immatriculation} de marque {$marque} (couleur {$couleur}) </p>";
  }
  */

  // renvoie le tableau de toutes les voitures de la BDD
  public static function getAllVoitures() {
    try {
      $rep = Model::$pdo->query("SELECT * FROM voiture");
      $rep->setFetchMode(PDO::FETCH_CLASS, 'ModelVoiture');
      return $rep->fetchAll();
    } catch (PDOException $e) {
      if (Conf::getDebug()) {
        echo $e->getMessage(); // affiche un message d'erreur
      } else {
        echo 'Une erreur est survenue <a href=""> retour a la page d\'accueil </a>';
      }
      die();
    }
  }

  public static function getVoitureByImmat($immat) {
    try {
      $sql = "SELECT * from voiture WHERE immatriculation=:nom_tag";
      $req_prep = Model::$pdo->prepare($sql);

      $values = array(
        "nom_tag" => $immat,
      );
      $req_prep->execute($values);

      $req_prep->setFetchMode(PDO::FETCH_CLASS, 'ModelVoiture');
      $tab_voit = $req_prep->fetchAll();
      if (empty($tab_voit))
        return false;
      return $tab_voit[0];
    } catch (PDOException $e) {
      if (Conf::getDebug()) {
        echo $e->getMessage();
      } else {
        echo 'Une erreur est survenue <a href=""> retour a la page d\'accueil </a>';
      }
      die();
    }
  }

  public function save() {
    try {
      $sql = "INSERT INTO voiture (immatriculation, marque, couleur) VALUES (:immatriculation, :marque, :couleur)";
      $req_prep = Model::$pdo->prepare($sql);

      $values = array(
        "immatriculation" => $this->immatriculation,
        "marque" => $this->marque,
        "couleur" => $this->couleur,
      );
      $req_prep->execute($values);
    } catch (PDOException $e) {
      if (Conf::getDebug()) {
        echo $e->getMessage();
      } else {
        echo 'Une erreur est survenue <a href=""> retour a la page d\'accueil </a>';
      }
      die();
    }
  }
}
?>
