<?php
$vImmatriculation = htmlspecialchars($v->getImmatriculation());
$vMarque = htmlspecialchars($v->getMarque());
$vCouleur = htmlspecialchars($v->getCouleur());
echo "<p> Voiture $vImmatriculation de marque $vMarque (couleur $vCouleur) </p>";
?>
<p><a href="index.php?action=readAll">Retour à la liste</a></p>
