<?php
require_once File::build_path(array("model", "ModelVoiture.php"));

class ControllerVoiture {

    public static function readAll() {
        $tab_v = ModelVoiture::getAllVoitures();
        $controller = 'voiture';
        $view = 'list';
        $pagetitle = 'Liste des voitures';
        require File::build_path(array("view", "view.php"));
    }

    public static function read() {
        $v = ModelVoiture::getVoitureByImmat($_GET['immat']);
        $controller = 'voiture';
        if ($v == false) {
            $view = 'error';
            $pagetitle = 'Erreur';
        } else {
            $view = 'detail';
            $pagetitle = 'Détail d\'une voiture';
        }
        require File::build_path(array("view", "view.php"));
    }

    public static function create() {
        $controller = 'voiture';
        $view = 'create';
        $pagetitle = 'Création d\'une voiture';
        require File::build_path(array("view", "view.php"));
    }

    public static function created() {
        $v = new ModelVoiture($_GET['marque'], $_GET['couleur'], $_GET['immatriculation']);
        $v->save();
        $tab_v = ModelVoiture::getAllVoitures();
        $controller = 'voiture';
        $view = 'created';
        $pagetitle = 'Voiture créée';
        require File::build_path(array("view", "view.php"));
    }
}
?>
