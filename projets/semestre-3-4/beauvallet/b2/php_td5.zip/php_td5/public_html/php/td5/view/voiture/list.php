<?php
foreach ($tab_v as $v) {
    $vImmatriculation = htmlspecialchars($v->getImmatriculation());
    $vImmatriculationUrl = rawurlencode($v->getImmatriculation());
    echo '<p> Voiture d\'immatriculation <a href="index.php?action=read&immat='
       . $vImmatriculationUrl . '">' . $vImmatriculation . '</a>.</p>';
}
?>
