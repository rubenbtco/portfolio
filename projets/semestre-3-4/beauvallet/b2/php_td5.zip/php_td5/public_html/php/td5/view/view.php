<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title><?php echo $pagetitle; ?></title>
    </head>
    <body>
        <nav>
            <a href="index.php?action=readAll">Gestion des voitures</a> |
            <a href="index.php?action=readAll&controller=utilisateur">Gestion des utilisateurs</a> |
            <a href="index.php?action=readAll&controller=trajet">Gestion des trajets</a>
        </nav>
<?php
$filepath = File::build_path(array("view", $controller, "$view.php"));
require $filepath;
?>
        <p style="border: 1px solid black;text-align:right;padding-right:1em;">
            Site de covoiturage de Ruben Battocchio
        </p>
    </body>
</html>
