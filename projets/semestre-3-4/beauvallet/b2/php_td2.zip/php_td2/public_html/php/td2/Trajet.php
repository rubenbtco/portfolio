<?php
require_once 'Model.php';

class Trajet {

  private $id;
  private $depart;
  private $arrivee;
  private $date;
  private $nbplaces;
  private $prix;
  private $conducteur_login;

  // getter générique
  public function get($nom_attribut) {
       return $this->$nom_attribut;
  }

  // setter générique
  public function set($nom_attribut, $valeur) {
       $this->$nom_attribut = $valeur;
  }

  // constructeur à partir d'un tableau associatif
  // $data est optionnel pour que PDO puisse appeler le constructeur sans argument
  public function __construct($data = NULL) {
    if (!is_null($data)) {
      foreach ($data as $cle => $valeur) {
        $this->set($cle, $valeur);
      }
    }
  }

  public function afficher() {
    $depart = htmlspecialchars($this->depart);
    $arrivee = htmlspecialchars($this->arrivee);
    $conducteur = htmlspecialchars($this->conducteur_login);
    echo "<p> Trajet n°{$this->id} de {$depart} à {$arrivee} le {$this->date} :"
       . " {$this->nbplaces} place(s) à {$this->prix} € (conducteur : {$conducteur}) </p>";
  }

  // renvoie le tableau de tous les trajets de la BDD
  public static function getAllTrajets() {
    try {
      $rep = Model::$pdo->query("SELECT * FROM trajet");
      $rep->setFetchMode(PDO::FETCH_CLASS, 'Trajet');
      return $rep->fetchAll();
    } catch (PDOException $e) {
      if (Conf::getDebug()) {
        echo $e->getMessage();
      } else {
        echo 'Une erreur est survenue <a href=""> retour a la page d\'accueil </a>';
      }
      die();
    }
  }
}
?>
