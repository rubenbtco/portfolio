<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title> Covoiturage </title>
    </head>

    <body>
        <?php
          require_once 'Utilisateur.php';
          require_once 'Trajet.php';

          echo "<h2>Liste des utilisateurs :</h2>";
          foreach (Utilisateur::getAllUtilisateurs() as $utilisateur) {
              $utilisateur->afficher();
          }

          echo "<h2>Liste des trajets :</h2>";
          foreach (Trajet::getAllTrajets() as $trajet) {
              $trajet->afficher();
          }
        ?>
    </body>
</html>
