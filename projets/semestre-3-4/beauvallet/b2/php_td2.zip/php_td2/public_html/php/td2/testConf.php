<?php
  // On inclut les fichiers de classe PHP avec require_once
  // pour éviter qu'ils soient inclus plusieurs fois
  require_once 'Conf.php';

  // On affiche les informations de la base de donnees
  echo "<p> Hôte : " . Conf::getHostname() . "</p>";
  echo "<p> Base de données : " . Conf::getDatabase() . "</p>";
  echo "<p> Login : " . Conf::getLogin() . "</p>";
  echo "<p> Mot de passe : '" . Conf::getPassword() . "'</p>";
?>
