<?php
require_once 'Model.php';

class Utilisateur {

  private $login;
  private $nom;
  private $prenom;

  // getter générique
  public function get($nom_attribut) {
       return $this->$nom_attribut;
  }

  // setter générique
  public function set($nom_attribut, $valeur) {
       $this->$nom_attribut = $valeur;
  }

  // constructeur à partir d'un tableau associatif
  // $data est optionnel pour que PDO puisse appeler le constructeur sans argument
  public function __construct($data = NULL) {
    if (!is_null($data)) {
      foreach ($data as $cle => $valeur) {
        $this->set($cle, $valeur);
      }
    }
  }

  public function afficher() {
    $login = htmlspecialchars($this->login);
    $nom = htmlspecialchars($this->nom);
    $prenom = htmlspecialchars($this->prenom);
    echo "<p> Utilisateur {$login} : {$prenom} {$nom} </p>";
  }

  // renvoie le tableau de tous les utilisateurs de la BDD
  public static function getAllUtilisateurs() {
    try {
      $rep = Model::$pdo->query("SELECT * FROM utilisateur");
      $rep->setFetchMode(PDO::FETCH_CLASS, 'Utilisateur');
      return $rep->fetchAll();
    } catch (PDOException $e) {
      if (Conf::getDebug()) {
        echo $e->getMessage();
      } else {
        echo 'Une erreur est survenue <a href=""> retour a la page d\'accueil </a>';
      }
      die();
    }
  }
}
?>
