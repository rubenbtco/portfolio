<?php
require_once 'Model.php';

class Voiture {

  private $marque;
  private $couleur;
  private $immatriculation;

  // un getter
  public function getMarque() {
       return $this->marque;
  }

  // un setter
  public function setMarque($marque2) {
       $this->marque = $marque2;
  }

  public function getCouleur() {
       return $this->couleur;
  }

  public function setCouleur($couleur2) {
       $this->couleur = $couleur2;
  }

  public function getImmatriculation() {
       return $this->immatriculation;
  }

  // On limite l'immatriculation à 8 caractères
  public function setImmatriculation($immatriculation2) {
       if (strlen($immatriculation2) <= 8) {
           $this->immatriculation = $immatriculation2;
       } else {
           $this->immatriculation = substr($immatriculation2, 0, 8);
       }
  }

  // un constructeur
  // La syntaxe ... = NULL signifie que l'argument est optionel
  // Si un argument optionnel n'est pas fourni,
  // alors il prend la valeur par défaut, NULL dans notre cas
  public function __construct($m = NULL, $c = NULL, $i = NULL)  {
   if (!is_null($m) && !is_null($c) && !is_null($i)) {
     // Si aucun de $m, $c et $i sont nuls,
     // c'est forcement qu'on les a fournis
     // donc on retombe sur le constructeur à 3 arguments
     $this->marque = $m;
     $this->couleur = $c;
     $this->setImmatriculation($i);
   }
  }

  // une methode d'affichage.
  // htmlspecialchars() evite d'interpreter du HTML saisi dans le formulaire (XSS)
  public function afficher() {
    $immatriculation = htmlspecialchars($this->immatriculation);
    $marque = htmlspecialchars($this->marque);
    $couleur = htmlspecialchars($this->couleur);
    echo "<p> Voiture {$immatriculation} de marque {$marque} (couleur {$couleur}) </p>";
  }

  // renvoie le tableau de toutes les voitures de la BDD
  public static function getAllVoitures() {
    try {
      $rep = Model::$pdo->query("SELECT * FROM voiture");
      $rep->setFetchMode(PDO::FETCH_CLASS, 'Voiture');
      return $rep->fetchAll();
    } catch (PDOException $e) {
      if (Conf::getDebug()) {
        echo $e->getMessage(); // affiche un message d'erreur
      } else {
        echo 'Une erreur est survenue <a href=""> retour a la page d\'accueil </a>';
      }
      die();
    }
  }
}
?>
