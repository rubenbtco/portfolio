<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title> Liste des voitures </title>
    </head>

    <body>
        <h2>Liste des voitures :</h2>
        <?php
          require_once 'Voiture.php';

          $tab_voit = Voiture::getAllVoitures();
          foreach ($tab_voit as $voiture) {
              $voiture->afficher();
          }
        ?>
    </body>
</html>
