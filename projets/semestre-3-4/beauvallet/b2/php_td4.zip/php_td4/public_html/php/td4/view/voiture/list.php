<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Liste des voitures</title>
    </head>
    <body>
        <?php
        foreach ($tab_v as $v) {
            $immat = htmlspecialchars($v->getImmatriculation());
            echo '<p> Voiture d\'immatriculation <a href="routeur.php?action=read&immat='
               . rawurlencode($v->getImmatriculation()) . '">' . $immat . '</a>.</p>';
        }
        ?>
    </body>
</html>
