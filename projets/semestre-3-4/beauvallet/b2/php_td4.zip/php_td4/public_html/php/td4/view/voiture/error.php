<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Erreur</title>
    </head>
    <body>
        <p>Erreur : cette voiture n'existe pas.</p>
        <p><a href="routeur.php?action=readAll">Retour à la liste</a></p>
    </body>
</html>
