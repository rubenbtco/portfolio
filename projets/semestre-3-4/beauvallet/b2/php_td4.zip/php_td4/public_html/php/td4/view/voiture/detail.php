<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Détail d'une voiture</title>
    </head>
    <body>
        <?php
        echo '<p> Voiture ' . htmlspecialchars($v->getImmatriculation())
           . ' de marque ' . htmlspecialchars($v->getMarque())
           . ' (couleur ' . htmlspecialchars($v->getCouleur()) . ') </p>';
        ?>
        <p><a href="routeur.php?action=readAll">Retour à la liste</a></p>
    </body>
</html>
