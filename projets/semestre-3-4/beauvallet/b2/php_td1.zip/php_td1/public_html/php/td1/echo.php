<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title> Mon premier php </title>
    </head>

    <body>
        Voici le résultat du script PHP :
        <?php
          // Ceci est un commentaire PHP sur une ligne
          /* Ceci est le 2ème type de commentaire PHP
          sur plusieurs lignes */

          // On met la chaine de caractères "hello" dans la variable 'texte'
          // Les noms de variable commencent par $ en PHP
          $texte = "hello world !";

          // On écrit le contenu de la variable 'texte' dans la page Web
          echo $texte;

          // 1) Avec trois variables
          $marque = "Renault";
          $couleur = "bleu";
          $immatriculation = "256AB34";

          echo "<p> Voiture $immatriculation de marque $marque (couleur $couleur) </p>";

          // 2) Avec un tableau associatif
          $voiture = array(
              'marque' => 'Peugeot',
              'couleur' => 'rouge',
              'immatriculation' => '123XY456'
          );

          var_dump($voiture);

          echo "<p> Voiture {$voiture['immatriculation']} de marque {$voiture['marque']} (couleur {$voiture['couleur']}) </p>";

          // 3) Avec une liste de voitures
          $voitures = array();
          $voitures[] = $voiture;
          $voitures[] = array('marque' => 'Renault', 'couleur' => 'bleu', 'immatriculation' => '256AB34');
          $voitures[] = array('marque' => 'Citroën', 'couleur' => 'vert', 'immatriculation' => '789CD01');

          var_dump($voitures);

          echo "<h2>Liste des voitures :</h2>";
          if (empty($voitures)) {
              echo "<p>Il n'y a aucune voiture.</p>";
          } else {
              echo "<ul>";
              foreach ($voitures as $v) {
                  echo "<li> Voiture {$v['immatriculation']} de marque {$v['marque']} (couleur {$v['couleur']}) </li>";
              }
              echo "</ul>";
          }
        ?>
    </body>
</html>
