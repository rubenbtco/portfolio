<?php
class Voiture {

  private $marque;
  private $couleur;
  private $immatriculation;

  // un getter
  public function getMarque() {
       return $this->marque;
  }

  // un setter
  public function setMarque($marque2) {
       $this->marque = $marque2;
  }

  public function getCouleur() {
       return $this->couleur;
  }

  public function setCouleur($couleur2) {
       $this->couleur = $couleur2;
  }

  public function getImmatriculation() {
       return $this->immatriculation;
  }

  // On limite l'immatriculation à 8 caractères
  public function setImmatriculation($immatriculation2) {
       if (strlen($immatriculation2) <= 8) {
           $this->immatriculation = $immatriculation2;
       } else {
           $this->immatriculation = substr($immatriculation2, 0, 8);
       }
  }

  // un constructeur
  public function __construct($m, $c, $i)  {
   $this->marque = $m;
   $this->couleur = $c;
   $this->setImmatriculation($i);
  }

  // une methode d'affichage.
  // htmlspecialchars() evite d'interpreter du HTML saisi dans le formulaire (XSS)
  public function afficher() {
    $immatriculation = htmlspecialchars($this->immatriculation);
    $marque = htmlspecialchars($this->marque);
    $couleur = htmlspecialchars($this->couleur);
    echo "<p> Voiture {$immatriculation} de marque {$marque} (couleur {$couleur}) </p>";
  }
}
?>
