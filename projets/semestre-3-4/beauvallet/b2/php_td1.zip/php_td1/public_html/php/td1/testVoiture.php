<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title> Test de la classe Voiture </title>
    </head>

    <body>
        <?php
          require_once 'Voiture.php';

          $voiture1 = new Voiture("Peugeot", "rouge", "123XY456");
          $voiture1->afficher();

          // Test du setter : l'immatriculation est limitée à 8 caractères
          $voiture2 = new Voiture("Citroën", "vert", "ABCDEFGHIJKL");
          $voiture2->afficher();
        ?>
    </body>
</html>
