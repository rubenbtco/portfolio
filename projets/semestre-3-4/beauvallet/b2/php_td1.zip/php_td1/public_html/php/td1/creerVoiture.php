<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title> Création d'une voiture </title>
    </head>

    <body>
        <?php
          require_once 'Voiture.php';

          if (!isset($_POST['marque'], $_POST['couleur'], $_POST['immatriculation'])) {
              echo "<p>Aucune information reçue.</p>";
          } else {
              $voiture = new Voiture($_POST['marque'], $_POST['couleur'], $_POST['immatriculation']);
              $voiture->afficher();
          }
        ?>
    </body>
</html>
