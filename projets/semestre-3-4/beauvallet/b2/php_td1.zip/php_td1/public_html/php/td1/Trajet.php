<?php
class Trajet {

  private $id;
  private $depart;
  private $arrivee;
  private $date;
  private $nbplaces;
  private $prix;
  private $conducteur_login;

  // getter générique
  public function get($nom_attribut) {
       return $this->$nom_attribut;
  }

  // setter générique
  public function set($nom_attribut, $valeur) {
       $this->$nom_attribut = $valeur;
  }

  // constructeur à partir d'un tableau associatif
  public function __construct($data) {
    foreach ($data as $cle => $valeur) {
      $this->set($cle, $valeur);
    }
  }

  public function afficher() {
    echo "<p> Trajet n°{$this->id} de {$this->depart} à {$this->arrivee} le {$this->date} :"
       . " {$this->nbplaces} place(s) à {$this->prix} € (conducteur : {$this->conducteur_login}) </p>";
  }
}
?>
