<?php
class Utilisateur {

  private $login;
  private $nom;
  private $prenom;

  // getter générique
  public function get($nom_attribut) {
       return $this->$nom_attribut;
  }

  // setter générique
  public function set($nom_attribut, $valeur) {
       $this->$nom_attribut = $valeur;
  }

  // constructeur à partir d'un tableau associatif
  public function __construct($data) {
    foreach ($data as $cle => $valeur) {
      $this->set($cle, $valeur);
    }
  }

  public function afficher() {
    echo "<p> Utilisateur {$this->login} : {$this->prenom} {$this->nom} </p>";
  }
}
?>
