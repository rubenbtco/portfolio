<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title> Test du covoiturage </title>
    </head>

    <body>
        <?php
          require_once 'Utilisateur.php';
          require_once 'Trajet.php';

          $utilisateur = new Utilisateur(array(
              'login' => 'rbattocchio',
              'nom' => 'Battocchio',
              'prenom' => 'Ruben'
          ));
          $utilisateur->afficher();

          $trajet = new Trajet(array(
              'id' => 1,
              'depart' => 'Montpellier',
              'arrivee' => 'Marseille',
              'date' => '2026-10-05',
              'nbplaces' => 3,
              'prix' => 15,
              'conducteur_login' => $utilisateur->get('login')
          ));
          $trajet->afficher();

          // Test du setter et du getter génériques
          $trajet->set('nbplaces', 2);
          echo "<p> Après réservation d'une place : " . $trajet->get('nbplaces') . " place(s) restante(s) </p>";
        ?>
    </body>
</html>
