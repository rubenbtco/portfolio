<?php
if($bdd = mysqli_connect('localhost', 'battocchio', '', 'leclerc')) {
    $requete = "Select * from client";
    $resultat = mysqli_query($bdd, $requete);
    while($donnees = mysqli_fetch_assoc($resultat)) {
        echo $donnees['nom'];
        echo $donnees['prenom'];
        echo "<br>";    
    }
    $sql_insert = "INSERT INTO client (nom, prenom) VALUES ('Dupont', 'Jean')";
    mysqli_query($bdd, $sql_insert);
    mysqli_close($bdd);
} 
else {
    echo 'Erreur';
}
?>