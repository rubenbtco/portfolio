<?php
try {
    $bdd = new PDO('mysql:host=localhost;dbname=personnel;charset=utf8', 'root', '');
    $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Exception $e) {
    die('Erreur : ' . $e->getMessage());
}

$reponse = $bdd->query('SELECT NomEmpl, PrenomEmpl FROM employe');
$employes = $reponse->fetchAll();
$total = count($employes);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Liste des employés</title>
</head>
<body>
    <h1>Liste des employés</h1>
    <ul>
        <?php foreach ($employes as $emp): ?>
            <li><?= htmlspecialchars($emp['NomEmpl'], ENT_QUOTES, 'UTF-8') ?> <?= htmlspecialchars($emp['PrenomEmpl'], ENT_QUOTES, 'UTF-8') ?></li>
        <?php endforeach; ?>
    </ul>
    <p>Total : <?= $total ?> employé(s)</p>
</body>
</html>