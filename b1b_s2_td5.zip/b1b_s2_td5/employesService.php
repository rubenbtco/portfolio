<?php
require 'fonctions.php';
$bdd = getBdd();

if (isset($_POST['service'])) {
    $codeServ = $_POST['service'];
    
    $reqServ = $bdd->prepare('SELECT DesiServ FROM service WHERE CodeServ = ?');
    $reqServ->execute([$codeServ]);
    $serviceInfo = $reqServ->fetch();
    $nomService = $serviceInfo ? $serviceInfo['DesiServ'] : '';

    $reqEmp = $bdd->prepare('SELECT Matricule, NomEmpl, PrenomEmpl FROM employe WHERE ServEmpl = ?');
    $reqEmp->execute([$codeServ]);
    $employes = $reqEmp->fetchAll();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Liste des employés du service</title>
</head>
<body>
    <?php if (isset($_POST['service'])): ?>
    <h1>Liste des employés du service <?= escape($nomService) ?></h1>
    <table>
        <thead>
            <tr>
                <th>Matricule</th>
                <th>Nom</th>
                <th>Prénom</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($employes as $emp): ?>
            <tr>
                <td><?= escape($emp['Matricule']) ?></td>
                <td><?= escape($emp['NomEmpl']) ?></td>
                <td><?= escape($emp['PrenomEmpl']) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php else: ?>
    <p>Aucun service sélectionné.</p>
    <?php endif; ?>
</body>
</html>