<?php
require 'fonctions.php';
$bdd = getBdd();
$services = $bdd->query('SELECT CodeServ, DesiServ FROM service')->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Sélection du service</title>
</head>
<body>
    <h1>Choix d'un service</h1>
    <form action="employesService.php" method="post">
        <p>
            <label>Service : 
                <select name="service">
                    <?php foreach ($services as $srv): ?>
                    <option value="<?= escape($srv['CodeServ']) ?>"><?= escape($srv['DesiServ']) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
        </p>
        <p><button type="submit">Afficher les employés</button></p>
    </form>
</body>
</html>