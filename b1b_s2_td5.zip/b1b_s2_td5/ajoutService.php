<?php
require 'fonctions.php';
$bdd = getBdd();

$message = "";
if (isset($_POST['code']) && isset($_POST['designation'])) {
    $req = $bdd->prepare('INSERT INTO service (CodeServ, DesiServ) VALUES (?, ?)');
    $req->execute([$_POST['code'], $_POST['designation']]);
    $message = "L'ajout a réussi !";
}

$services = $bdd->query('SELECT CodeServ, DesiServ FROM service')->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Ajout d'un service</title>
</head>
<body>
    <h1>Liste des services</h1>
    <table>
        <thead>
            <tr>
                <th>Code</th>
                <th>Désignation</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($services as $srv): ?>
            <tr>
                <td><?= escape($srv['CodeServ']) ?></td>
                <td><?= escape($srv['DesiServ']) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <h1>Ajout d'un service</h1>
    <form action="" method="post">
        <p><label>Code : <input type="text" name="code" required></label></p>
        <p><label>Désignation : <input type="text" name="designation" required></label></p>
        <p><button type="submit">Ajouter le service</button></p>
    </form>
    
    <?php if ($message): ?>
    <p><?= $message ?></p>
    <?php endif; ?>
</body>
</html>