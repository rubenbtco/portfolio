<?php
try {
    $bdd = new PDO('mysql:host=localhost;dbname=personnel;charset=utf8', 'root', '');
    $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Exception $e) {
    die('Erreur : ' . $e->getMessage());
}

$reponse = $bdd->query('SELECT Matricule, NomEmpl, PrenomEmpl FROM employe');
$employes = $reponse->fetchAll();
$total = count($employes);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Tableau des employés</title>
</head>
<body>
    <h1>Tableau des employés</h1>
    <table>
        <thead>
            <tr>
                <th>Matricule</th>
                <th>Nom</th>
                <th>Prénom</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($employes as $emp): ?>
            <tr>
                <td><?= htmlspecialchars($emp['Matricule'], ENT_QUOTES, 'UTF-8') ?></td>
                <td><?= htmlspecialchars($emp['NomEmpl'], ENT_QUOTES, 'UTF-8') ?></td>
                <td><?= htmlspecialchars($emp['PrenomEmpl'], ENT_QUOTES, 'UTF-8') ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <p>Total : <?= $total ?> employé(s)</p>
</body>
</html>