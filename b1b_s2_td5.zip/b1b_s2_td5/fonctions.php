<?php
function getBdd() {
    try {
        $bdd = new PDO('mysql:host=localhost;dbname=personnel;charset=utf8', 'root', '');
        $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $bdd;
    } catch (Exception $e) {
        die('Erreur : ' . $e->getMessage());
    }
}

function escape($valeur) {
    return htmlspecialchars($valeur, ENT_QUOTES, 'UTF-8');
}
?>