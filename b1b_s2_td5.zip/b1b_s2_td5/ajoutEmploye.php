<?php
require 'fonctions.php';
$bdd = getBdd();

$message = "";
if (isset($_POST['matricule']) && isset($_POST['nom']) && isset($_POST['prenom']) && isset($_POST['service'])) {
    $cadre = isset($_POST['cadre']) ? 'o' : 'n';
    
    $req = $bdd->prepare('INSERT INTO employe (Matricule, NomEmpl, PrenomEmpl, CodeCadre, ServEmpl) VALUES (?, ?, ?, ?, ?)');
    $req->execute([
        $_POST['matricule'], 
        $_POST['nom'], 
        $_POST['prenom'], 
        $cadre, 
        $_POST['service']
    ]);
    
    $message = "L'ajout a réussi !";
}

$services = $bdd->query('SELECT CodeServ, DesiServ FROM service')->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Ajout d'un employé</title>
</head>
<body>
    <h1>Ajout d'un employé</h1>
    <form action="" method="post">
        <p><label>Matricule : <input type="text" name="matricule" required></label></p>
        <p><label>Nom : <input type="text" name="nom" required></label></p>
        <p><label>Prénom : <input type="text" name="prenom" required></label></p>
        <p><label>Cadre ? <input type="checkbox" name="cadre"></label></p>
        <p>
            <label>Service : 
                <select name="service" required>
                    <?php foreach ($services as $srv): ?>
                    <option value="<?= escape($srv['CodeServ']) ?>"><?= escape($srv['DesiServ']) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
        </p>
        <p><button type="submit">Ajouter l'employé</button></p>
    </form>
    
    <?php if ($message): ?>
    <p><?= $message ?></p>
    <?php endif; ?>
</body>
</html>